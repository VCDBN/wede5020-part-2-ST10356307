var slides = document.getElementsByClassName("slide");
var currentIndex = 0;

function showSlide() {
  // Hide all slides
  for (var i = 0; i < slides.length; i++) {
    slides[i].classList.remove("active");
  }

  // Show the current slide
  slides[currentIndex].classList.add("active");

  // Update the index for the next slide
  currentIndex = (currentIndex + 1) % slides.length;

  // Call the function again after a certain time interval (e.g., 3 seconds)
  setTimeout(showSlide, 3000);
}

// Start the slideshow
showSlide('start');